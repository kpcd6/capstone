public class Drone 
{
	private int ID;
	private String Name;
	private int teamID;
	private String teamRole;
	private boolean isActive;
	private boolean isWepCooldown;
	private int ammoLeft;
	private int shotCount;
	private int hitCount;
	private double xCoord;
	private double yCoord;
	private double zCoord;
	
	Drone(int id, String name, int teamid, String role)//constructor
	{
		id=ID;
		name=Name;
		teamid=teamID;
		role=teamRole;
	}
	
	public int getShotCount()
	{
		return 0;
	}
	
	public int getID()
	{
		return 0;
	}
	
	public String getName()
	{
		return null;
	}
	
	public boolean getStatus()
	{
		return false;
	}
	
	public int getTeamID()
	{
		return 0;
	}
	
	public String getRole()
	{
		return null;
	}
	
	public void shoot()
	{
		
	}
	
	protected void getShot()
	{
		
	}
	
	protected void startWepCooldown()
	{
		
	}
	
	protected void deactivate()
	{
		
	}
	
	protected boolean coordCheck()
	{
		return false;
	}
}
