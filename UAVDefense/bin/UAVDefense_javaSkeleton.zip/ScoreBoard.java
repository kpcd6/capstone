public class ScoreBoard 
{
	private static final int START_TIME=180;
	private int currentTime;
	
	public void updateBoard()
	{
		
	}
	
	private boolean checkRoundOver()
	{
		return false;
	}
}
