public class Team 
{
	private int teamID;
	private double shotScore;
	private int targetsHit;
	
	Team (int tid)//constructor
	{
		tid=teamID;
	}
	
	public double getShotScore()
	{
		return 0;
	}
	
	public int getTargetHit()
	{
		return 0;
	}
	
	public void calcScore()
	{
		
	}
}
